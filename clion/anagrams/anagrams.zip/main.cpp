#include <iostream>
#include <fstream>

using namespace std;

int check(string & s) {
    for (int i = 0; i < s.length() / 2; i++) {
        if (s[i] != s[s.length() - 1 - i]) return 0;
    }
    return 1;
}

int main() {
    ifstream input;
    input.open("anagrams.txt");
    string s;
    int count = 0;
    int anagrams_count = 0;
    while (!input.eof()) {
        input >> s;
        count++;
        anagrams_count += check(s);
    }
    input.close();
    cout << "Amount of words: " << count << endl;
    cout << "Amount of anagrams: " << anagrams_count << endl;
    return 0;
}